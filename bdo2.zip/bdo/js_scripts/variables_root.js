const loading = document.querySelector('#bysy_indicator');
const err_box = document.querySelector('#id12c');
const err_msg = document.querySelector('#err_message');
const login_form = document.querySelector('#idc');
